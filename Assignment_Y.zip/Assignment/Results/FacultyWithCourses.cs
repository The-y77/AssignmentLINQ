﻿namespace Assignment.Results
{
    public class FacultyWithCourses
    {
        public string? FacultyName { get; set; }
        public int CourseCount { get; set; }
    }
}
